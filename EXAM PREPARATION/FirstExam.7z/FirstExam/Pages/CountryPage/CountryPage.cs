﻿namespace ExamPreparation.Pages.CountryPage
{
    using OpenQA.Selenium;

    public partial class CountryPage : BasePage
    {
        public CountryPage(IWebDriver driver) :base(driver)
        {

        }
    }
}
