﻿namespace Exam0508.Pages.AutomateThePlanetPage
{
	using System.Collections.Generic;
	using System.Linq;
	using OpenQA.Selenium;

	public partial class ATPPage
    {
	    public IWebElement Blog => Driver.FindElement(By.Id("menu-item-6"));

	    public List<IWebElement> Articles => Driver.FindElements(By.TagName("Article")).ToList();

	    public IWebElement Navigation
        {
            get
            {
                var tests = Driver.FindElement(By.CssSelector(@"#tve_editor > div.thrv_wrapper.thrv_contents_table.tve_ct.tve_clearfix.tve_update_contents_table.tve_green"));
                return tests;
            }
        }

	    public List<IWebElement> NavigationLinks => Navigation.FindElements(By.TagName("a")).ToList();

	    public List<string> NavLinksToHeaderTwo => Navigation
		    .FindElements(By.ClassName("tve_ct_level0"))
		    .ToList()
		    .Select(h => h.Text)
		    .ToList();

	    public List<string> NavLinksToHeaderThree => Navigation
		    .FindElements(By.ClassName("tve_ct_level1"))
		    .ToList()
		    .Select(h => h.Text)
		    .ToList();

	    public IWebElement Content => Driver.FindElement(By.Id("tve_editor"));

	    public List<string> HeadersTwo => Driver
		    .FindElements(By.TagName("h2"))
		    .ToList()
		    .FindAll(t => t.Text != "")
		    .Select(h => h.Text)
		    .ToList();

	    public List<string> HeadersThree => Driver
		    .FindElements(By.TagName("h3"))
		    .ToList()
		    .FindAll(t => t.Text != "")
		    .Select(h => h.Text)
		    .ToList();
    }
}
