﻿namespace Exam0508.Pages
{
	using OpenQA.Selenium;

	public partial class TooltipPage : BasePage
    {
	    public TooltipPage(IWebDriver driver) : base(driver)
	    {
	    }
    }
}
