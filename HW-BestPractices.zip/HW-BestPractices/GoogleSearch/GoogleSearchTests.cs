﻿using GoogleSearch.Pages;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System.IO;
using System.Reflection;

namespace GoogleSearch
{
    [TestFixture]
    public class GoogleSearchTests
    {
        private IWebDriver driver;
        

        [SetUp]
        public void Init()
        {
            driver = new ChromeDriver(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location));
        }


        [Test]
        public void checkIfBrowserWillOpenSeleniumhqOrgSite()
        {
            var googleHomePage = new GoogleHomePage(driver);
            googleHomePage.Navigate();

            googleHomePage.SearchTextInput.SendKeys("Selenium");
            googleHomePage.SearchTextInput.SendKeys(Keys.Enter);

            //check first link href 
            //var searchHref = driver.FindElement(By.XPath(@"//*[@id=""rso""]/div[1]/div/div/div/div[1]/a[1]"));
            //Assert.AreEqual("https://www.seleniumhq.org/", searchHref.GetAttribute("href"));

            var googleResultPage = new GoogleResultPage(driver);
            googleResultPage.SearchSiteLink.Click();
            
            Assert.AreEqual("Selenium - Web Browser Automation", driver.Title);
            }

        [TearDown]
        public void TearDown()
        {
            driver.Quit();
        }
    }
}
