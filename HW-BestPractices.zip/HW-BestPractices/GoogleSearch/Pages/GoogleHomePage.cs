﻿using OpenQA.Selenium;

namespace GoogleSearch.Pages
{
    public class GoogleHomePage
    {
        private const string googleWebSite = "https://www.google.com/?gws_rd=ssl";

        private IWebDriver driver;

        public GoogleHomePage(IWebDriver webDriver)
        {
            this.driver = webDriver;
        }

        public IWebElement SearchTextInput => this.driver.FindElement(By.XPath(@"//*[@id=""tsf""]/div[2]/div[1]/div[1]/div/div[2]/input"));

        public void Navigate()
        {
            this.driver.Url = googleWebSite;
        }
    }
}
