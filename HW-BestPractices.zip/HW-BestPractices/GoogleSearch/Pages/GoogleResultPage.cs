﻿using OpenQA.Selenium;

namespace GoogleSearch.Pages
{
    public class GoogleResultPage
    {
        private const string googleWebSite = "https://www.google.com/?gws_rd=ssl";

        private IWebDriver driver;

        public GoogleResultPage(IWebDriver webDriver)
        {
            this.driver = webDriver;
        }

        public IWebElement SearchSiteLink => this.driver.FindElement(By.XPath(@"//*[@id=""rso""]/div[1]/div/div/div/div[1]/a[1]/h3/div"));

        public void Navigate()
        {
            this.driver.Url = googleWebSite;
        }
    }
}
